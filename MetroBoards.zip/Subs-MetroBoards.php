<?php

function metro_edit_board()
{
	global $smcFunc, $context, $boards;
	
	$request = $smcFunc['db_query']('', '
		SELECT size
		FROM {db_prefix}boards
		WHERE id_board = {int:board}
		LIMIT 1',
		array(
			'board' => $_REQUEST['boardid'],
		)
	);
	list ($size) = $smcFunc['db_fetch_row']($request);
	$smcFunc['db_free_result']($request);
	
	$context['board_sizes'] = array(
		0 => array(
			'name' => 'Small',
			'selected' => false,
		),
		1 => array(
			'name' => 'Medium',
			'selected' => false,
		),
		2 => array(
			'name' =>  'Big',
			'selected' => false,
		),
	);
	
	$context['board_sizes'][$size]['selected'] = true;
}