<?php
require_once('SSI.php');
db_extend('packages');

$smcFunc['db_add_column']('{db_prefix}boards', array('name' => 'size', 'type' => 'tinyint', 'size' => 1,));

add_integration_function('integrate_pre_include', '$sourcedir/Subs-MetroBoards.php',TRUE);
add_integration_function('integrate_edit_board','metro_edit_board',TRUE);